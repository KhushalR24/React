export const BASE_URL = 'http://localhost:3001'

//get data  from server
export const GET_API_DATA ='/posts'

//post data from server
export const POST_API_DATA ='/posts'

//delete a post by id
export const DELETE_API_DATA= '/posts/'

//update  a post by id
export const UPDATE_API_DATA='/posts/'